import UIKit

enum Currency {
    case cad
    case mxn
}

let usToCad = 1.45
let usToMxn =  23.95

var currency: Currency = .mxn


    

func convert(_ dollars: Double) -> Double {
    
    switch currency {
        
    case .cad:
        return dollars * usToCad
    case .mxn:
        return dollars * usToMxn
    }
}


func convert2(amountString: String) -> String? {
    
    let amount = Double(amountString)
    guard let unwrappedAmount = amount else {
    return nil
    }
   
    let money = convert(unwrappedAmount)
    var currencyFormatter: NumberFormatter = {
         let formatter = NumberFormatter()
         formatter.numberStyle = .currency
         return formatter
    }()
    return currencyFormatter.string(from: NSNumber(value: money))
}


var money = convert2(amountString: "4000")
if let unwrappedMoney = money {
    print(unwrappedMoney)
}







